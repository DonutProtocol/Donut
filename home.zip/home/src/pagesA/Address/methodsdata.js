
export default {
    data() {
        return {
            selecto: true,
            selectt: false,
            selects: false,
            states:false,
        }
    },
    components: {

    },
    methods: {
        switchs(e){
            if(e==1){
                this.selecto=true;
                this.selectt=false;
                this.selects=false;
            }
            if(e==2){
                this.selecto=false;
                this.selectt=true;
                this.selects=false;
            }
            if(e==3){
                this.selecto=false;
                this.selectt=false;
                this.selects=true;
            }
        },
        duplicates(){
            this.states=!this.states;
        }
    }
}
<template>
  <div class="Address">
    <div class="Address-c">
      <div class="Address-o"></div>
      <div class="Address-t">
        Address on Polygon and Polkadot will be accepted soon.
      </div>
      <div class="container Address-s">
        <div class="Address-so">
          <div class="Address-so-l">
            <div class="Address-so-ll">
              <img src="../../assets/graph/search statistics.svg" />
            </div>
            <div class="Address-so-lc">Search Statistics</div>
            <div class="Address-so-lr">163,456,425</div>
          </div>
          <div class="Address-so-r">
            <div class="Address-so-ll">
              <img src="../../assets/graph/recent search.svg" />
            </div>
            <div class="Address-so-lc">Recent Search</div>
            <div class="Address-so-lr">124,468</div>
          </div>
        </div>
        <div class="Address-st">
          <div class="Address-st-l">
            <div class="Address-st-ll">
              <img src="../../assets/graph/Search Framework/search.svg" />
            </div>
            <div class="Address-st-lr">
              <input placeholder="Search By Address" />
            </div>
          </div>
          <div class="Address-st-r">
            <img src="../../assets/graph/Search Framework/arrow-right.svg" />
          </div>
        </div>
        <div class="Address-ss">
          <div class="Address-sso">Address Information</div>
          <div class="Address-sst">
            <div class="Address-sst-l">
              <div
                class="Address-sst-lo"
                style="margin-top: 20px; color: #1a1a1a; font-weight: bold"
              >
                Address
              </div>
              <div class="Address-sst-lo">Balance</div>
              <div class="Address-sst-lo">Token Balance</div>
              <div class="Address-sst-lo">Transaction number</div>
              <div class="Address-sst-lo">Nonce</div>
            </div>
            <div class="Address-sst-r">
              <div
                class="Address-sst-ro"
                style="margin-top: 20px"
              >
                <div class="Address-sst-ro-l">0xb41f3c6547dbb832c0a860a16d741d379a896428</div>
                <div class="Address-sst-ro-c" @click="duplicates()">
                  <img src="../../assets/graph/fzz.png" />
                </div>
                <div class="Address-sst-ro-r">Copy</div>
              </div>
              <div class="Popup" v-if="states">Copied</div>
              <div class="Address-sst-ro">22,266.118671930000581492 ETH</div>
              <div
                class="Address-sst-ro"
                style="color: #6a90ff; font-weight: bold"
              >
                Check token balance
              </div>
              <div class="Address-sst-ro">29,900</div>
              <div class="Address-sst-ro">29075</div>
            </div>
          </div>
        </div>
        <div class="Address-sf">
           <div class="Address-sfo">
             <div class="Address-sfo-l" :class="{discolour:selecto}" @click="switchs(1)">Transactions(0)</div>
             <div class="Address-sfo-c" :class="{discolour:selectt}" @click="switchs(2)">Token Txns(0)</div>
             <div class="Address-sfo-r" :class="{discolour:selects}" @click="switchs(3)">Contract Internal Transactions(0)</div>
           </div>
           <div class="Address-sft">
             <div class="Address-sft-s">
               <img src="../../assets/graph/can't find the data.png" />
             </div>
             <div class="Address-sft-x">Sorry,we can not find the data.</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import methodsData from "./methodsdata";
export default {
  // 定义上面HTML模板中使用的变量
  mixins: [methodsData],
  name: "Address",
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "./Address.less";
</style>

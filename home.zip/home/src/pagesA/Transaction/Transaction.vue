<template>
  <div class="Transaction">
    <div class="Transaction-c">
      <div class="Transaction-o"></div>
      <div class="Transaction-t">
        Address on Polygon and Polkadot will be accepted soon.
      </div>
      <div class="container Transaction-s">
        <div class="Transaction-so">
          <div class="Transaction-so-l">
            <div class="Transaction-so-ll">
              <img src="../../assets/graph/search statistics.svg" />
            </div>
            <div class="Transaction-so-lc">Search Statistics</div>
            <div class="Transaction-so-lr">163,456,425</div>
          </div>
          <div class="Transaction-so-r">
            <div class="Transaction-so-ll">
              <img src="../../assets/graph/recent search.svg" />
            </div>
            <div class="Transaction-so-lc">Recent Search</div>
            <div class="Transaction-so-lr">124,468</div>
          </div>
        </div>
        <div class="Transaction-st">
          <div class="Transaction-st-l">
            <div class="Transaction-st-ll">
              <img src="../../assets/graph/Search Framework/search.svg" />
            </div>
            <div class="Transaction-st-lr">
              <input placeholder="Search By Address" />
            </div>
          </div>
          <div class="Transaction-st-r">
            <img src="../../assets/graph/Search Framework/arrow-right.svg" />
          </div>
        </div>
        <div class="Transaction-ss">
          <div class="Transaction-co">
            <div class="Transaction-coo">
              <div class="Transaction-coo-l">
                <div class="Transaction-coo-lo">
                  <div class="Transaction-coo-lo-l">
                    <img src="../../assets/graph/true-usd 1.png" />
                  </div>
                  <div class="Transaction-coo-lo-r">
                    <div class="Transaction-coo-lo-rs">TUSD</div>
                    <div class="Transaction-coo-lo-rx">16 TUSD</div>
                  </div>
                </div>
                <div class="Transaction-coo-lt">$16</div>
              </div>
              <div class="Transaction-coo-r">
                <div class="Transaction-coo-ro">
                  <div class="Transaction-coo-rol">
                    <div class="Transaction-coo-rol-l">
                      <img src="../../assets/graph/tokenlon 1.png" />
                    </div>
                    <div class="Transaction-coo-rol-r">
                      <div class="Transaction-coo-rol-ro">
                        <div class="Transaction-coo-rol-ro-l">Tokenlon</div>
                        <div class="Transaction-coo-rol-ro-r">
                          Contracts not open-source
                        </div>
                      </div>
                      <div class="Transaction-coo-rol-rt">
                        0x9bb8B4d6e37E4C31E89C6f9e6bC9172D1384485B
                      </div>
                    </div>
                  </div>
                  <div class="Transaction-coo-ror">
                    <div class="Transaction-coo-ror-l">Infinite</div>
                    <div class="Transaction-coo-ror-c">$16</div>
                    <div class="Transaction-coo-ror-r" style="color: #6A90FF;">Cancel</div>
                  </div>
                </div>
                <div class="Transaction-coo-ro" style="border-bottom: none;background: #F7F7FC;">
                  <div class="Transaction-coo-rol">
                    <div
                      class="Transaction-coo-rol-l"
                      style="
                        background: #666666;
                        border-radius: 50%;
                        margin-top: 10px;
                      "
                    ></div>
                    <div class="Transaction-coo-rol-r">
                      <div class="Transaction-coo-rol-ro">
                        <div class="Transaction-coo-rol-ro-l" style="color: #999999;">Unknown items</div>
                        <div class="Transaction-coo-rol-ro-r" style="background: #999999;color: #FFFFFF;">
                          Contracts not open-source
                        </div>
                      </div>
                      <div class="Transaction-coo-rol-rt" style="color: #999999;">
                        0x9bb8B4d6e37E4C31E89C6f9e6bC9172D1384485B
                      </div>
                    </div>
                  </div>
                  <div
                    class="Transaction-coo-ror"
                    style="border-radius: 0px 0px 0px 0px"
                  >
                    <div class="Transaction-coo-ror-l" style="color: #1A1A1A;">Infinite</div>
                    <div class="Transaction-coo-ror-c" style="color: #1A1A1A;">$16</div>
                    <div class="Transaction-coo-ror-r">Cancel</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="Transaction-sf">
          <div class="Transaction-sfc">
            <div class="Transaction-sfc-o">
              <div class="Transaction-sfc-ol">Amount Transacted</div>
              <div class="Transaction-sfc-or">16 TUSD</div>
            </div>
            <div class="Transaction-sfc-t">
              <div class="Transaction-sfc-tc">
                <div class="Transaction-sfc-tcl">From</div>
                <div class="Transaction-sfc-tcl">To</div>
                <div class="Transaction-sfc-tcl">Time</div>
                <div class="Transaction-sfc-tcl">
                  <div class="Transaction-sfc-tcl-l">Amount</div>
                  <div class="Transaction-sfc-tcl-r">
                    <img src="../../assets/graph/etc.svg" />
                  </div>
                </div>
              </div>
            </div>
            <div class="Transaction-sfc-s">
              <div class="Transaction-sfc-sl" style="color: #6A90FF;"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl">06-21-2021 04:32:02</div>
              <div class="Transaction-sfc-sl">11.3452 TUSD</div>
            </div>
            <div class="Transaction-sfc-s">
              <div class="Transaction-sfc-sl" style="color: #6A90FF;"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl">06-21-2021 04:32:02</div>
              <div class="Transaction-sfc-sl">11.3452 TUSD</div>
            </div>
            <div class="Transaction-sfc-s">
              <div class="Transaction-sfc-sl" style="color: #6A90FF;"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl">06-21-2021 04:32:02</div>
              <div class="Transaction-sfc-sl">11.3452 TUSD</div>
            </div>
            <div class="Transaction-sfc-s">
              <div class="Transaction-sfc-sl" style="color: #6A90FF;"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl"><span>13LGR1QjYkdi4adZV1Go123hygewdedg</span></div>
              <div class="Transaction-sfc-sl">06-21-2021 04:32:02</div>
              <div class="Transaction-sfc-sl">11.3452 TUSD</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import methodsData from "./methodsdata";
export default {
  // 定义上面HTML模板中使用的变量
  mixins: [methodsData],
  name: "Transaction",
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "./Transaction.less";
</style>

import Vue from 'vue'
import vuex from 'vuex'
Vue.use(vuex)
const state = {
    web3:null,
    account:null
}
const store = {
    state
}
export default store;
<template>
  <div class="Chain">
    <div class="Chain-c">
      <div class="Chain-o"></div>
      <div class="Chain-t">
        Address on Polygon and Polkadot will be accepted soon.
      </div>
      <div class="container Chain-s">
        <div class="Chain-so">
          <div class="Chain-so-l">
            <div class="Chain-so-ll">
              <img src="../../assets/graph/search statistics.svg" />
            </div>
            <div class="Chain-so-lc">Search Statistics</div>
            <div class="Chain-so-lr">163,456,425</div>
          </div>
          <div class="Chain-so-r">
            <div class="Chain-so-ll">
              <img src="../../assets/graph/recent search.svg" />
            </div>
            <div class="Chain-so-lc">Recent Search</div>
            <div class="Chain-so-lr">124,468</div>
          </div>
        </div>
        <div class="Chain-st">
          <div class="Chain-st-l">
            <div class="Chain-st-ll">
              <img src="../../assets/graph/Search Framework/search.svg" />
            </div>
            <div class="Chain-st-lr">
              <input placeholder="Search By Address" />
            </div>
          </div>
          <div class="Chain-st-r">
            <img src="../../assets/graph/Search Framework/arrow-right.svg" />
          </div>
        </div>
        <div class="Chain-ss">
          <div class="Chain-ss-o">
            <div class="Chain-ss-ol">
              <div class="Chain-ss-oo">Credit Score</div>
              <div class="Chain-ss-ot">63</div>
              <div class="Chain-ss-os">Mid Risk</div>
            </div>
            <div class="Chain-ss-or">
              <div class="Chain-ss-or-o">Credit Risk Report</div>
              <div class="Chain-ss-or-t">
                <div class="Chain-ss-or-tl">Address</div>
                <div class="Chain-ss-or-tr">0x9bb8B4d6e37E4C31E89C6f9e6bC</div>
              </div>
              <div class="Chain-ss-or-t" style="margin-top: 30px;border-bottom:none">
                <div class="Chain-ss-or-tl">Wallet Balance</div>
                <div class="Chain-ss-or-tr">3967303.85678369 ETH</div>
              </div>
            </div>
          </div>
          <div class="CreditAst-ss-t">
            <div class="CreditAst-ss-tl">
              <div class="CreditAst-ss-to">
                <div class="CreditAst-ss-tol">
                  <img src="../../assets/graph/filter.svg" />
                </div>
                <div class="CreditAst-ss-tor">
                  <img src="../../assets/graph/left arrow.svg" />
                </div>
              </div>
              <div class="CreditAst-ss-tt" v-for="(itme,index) in switList" :key="index">
                <div class="CreditAst-ss-tt-l">
                  <img :src="itme.src" />
                </div>
                <div class="CreditAst-ss-tt-r">{{itme.name}}</div>
              </div>
            </div>
            <div class="CreditAst-ss-tr"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import methodsData from "./methodsdata";
export default {
  // 定义上面HTML模板中使用的变量
  mixins: [methodsData],
  name: "CreditAst",
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "./CreditAst.less";
</style>

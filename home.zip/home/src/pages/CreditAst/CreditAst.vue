<template>
  <div class="Chain">
    <div class="Chain-c">
      <div class="Chain-o"></div>
      <div class="Chain-t">
        Address on Polygon and Polkadot will be accepted soon.
      </div>
      <div class="container Chain-s">
        <div class="Chain-so">
          <div class="Chain-so-l">
            <div class="Chain-so-ll">
              <img src="../../assets/graph/search statistics.svg" />
            </div>
            <div class="Chain-so-lc">Search Statistics</div>
            <div class="Chain-so-lr">163,456,425</div>
          </div>
          <div class="Chain-so-r">
            <div class="Chain-so-ll">
              <img src="../../assets/graph/recent search.svg" />
            </div>
            <div class="Chain-so-lc">Recent Search</div>
            <div class="Chain-so-lr">124,468</div>
          </div>
        </div>
        <div class="Chain-st">
          <div class="Chain-st-l">
            <div class="Chain-st-ll">
              <img src="../../assets/graph/Search Framework/search.svg" />
            </div>
            <div class="Chain-st-lr">
              <input placeholder="Search By Address" />
            </div>
          </div>
          <div class="Chain-st-r">
            <img src="../../assets/graph/Search Framework/arrow-right.svg" />
          </div>
        </div>
        <div class="Chain-ss">
          <div class="Chain-ss-o">
            <div class="Chain-ss-ol">
              <div class="Chain-ss-oo">Credit Score</div>
              <div class="Chain-ss-ot">63</div>
              <div class="Chain-ss-os">Mid Risk</div>
            </div>
            <div class="Chain-ss-or">
              <div class="Chain-ss-or-o">Credit Risk Report</div>
              <div class="Chain-ss-or-t">Address Info</div>
              <div class="Chain-ss-or-s">
                <div class="Chain-ss-or-so">
                  <div class="Chain-ss-or-sol">Normal Address</div>
                  <div class="Chain-ss-or-sor">0x9bb8B4d6e37E4C31E89C6f9e6bC9172D1384485B</div>
                </div>
                <div class="Chain-ss-or-so">
                  <div class="Chain-ss-or-sol" style="color: #666666;">Name</div>
                  <div class="Chain-ss-or-sor">Maker: Deployer 1</div>
                </div>
                <div class="Chain-ss-or-so">
                  <div class="Chain-ss-or-sol" style="color: #666666;">Balance</div>
                  <div class="Chain-ss-or-sor">2.328374264107065155 ETH</div>
                </div>
                <div class="Chain-ss-or-so">
                  <div class="Chain-ss-or-sol" style="color: #666666;">Token Balance</div>
                  <div class="Chain-ss-or-sor" style="font-weight: bold;color: #6A90FF;">Check token balance</div>
                </div>
                <div class="Chain-ss-or-so">
                  <div class="Chain-ss-or-sol" style="color: #666666;">Transaction number</div>
                  <div class="Chain-ss-or-sor">632</div>
                </div>
              </div>
            </div>
          </div>
          <div class="CreditAst-ss-t">
            <div class="CreditAst-ss-tl" :class="{Creditl:statuss}">
              <div class="CreditAst-ss-to">
                <div class="CreditAst-ss-tol" @click="openr()">
                  <img :src="filter" />
                </div>
                <div class="CreditAst-ss-tor" @click="Putaway()" v-if="statuss==false">
                  <img :src="arrowl" />
                </div>
              </div>
              <div class="CreditAst-ss-tt" v-for="(itme,index) in switList" :key="index" @click="switchs(itme)">
                <div class="CreditAst-ss-tt-l">
                  <img :src="itme.src" />
                </div>
                <div class="CreditAst-ss-tt-r" :class="{CreditAsttr:itme.status}">{{itme.name}}</div>
              </div>
              <div class="CreditAst-ss-tt" @click="shrtat()">
                <div class="CreditAst-ss-tt-l">
                  <img src="../../assets/graph/Alerts/off.svg" />
                </div>
                <div class="CreditAst-ss-tt-r" v-if="statuss==false">Alerts</div>
                <div class="CreditAst-ss-tt-rr" :class="{rotatetr:rotates}" v-if="statuss==false">
                  <img src="../../assets/graph/jtx.png" />
                </div>
              </div>
              <div class="CreditAst-ss-ts" v-if="rotates">
                <div class="CreditAst-ss-tss" :class="{Crso:selecto}" @click="choices(1)">Large Transfer</div>
                <div class="CreditAst-ss-tss" :class="{Crso:selectt}" @click="choices(2)">Risk Transfer</div>
                <div class="CreditAst-ss-tss" :class="{Crso:selects}" @click="choices(3)">Anonymous Transfer</div>
              </div>
            </div>
            <div class="CreditAst-ss-tr">
              <div class="CreditAst-ss-tr-o">
                <div class="CreditAst-ss-tr-ol">Recent month trading path chart</div>
                <div class="CreditAst-ss-tr-or">
                  <div class="CreditAst-ss-tr-or-l">1Month</div>
                  <div class="CreditAst-ss-tr-or-r">
                    <img src="../../assets/graph/jtxb.png" />
                  </div>
                </div>
              </div>
              <div class="CreditAst-ss-tr-t">
                <div class="CreditAst-ss-tr-tl">ETH</div>
                <div class="CreditAst-ss-tr-tl" 
                style="background: #FFFFFF;box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.2);color: #999999;margin-left: 15px;"
                >POK</div>
                <div class="CreditAst-ss-tr-tl"
                style="background: #FFFFFF;box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.2);color: #999999;margin-left: 15px;"
                >MATIC</div>
                <div class="CreditAst-ss-tr-tl"
                style="background: #FFFFFF;box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.2);color: #1A1A1A;margin-left: 15px;"
                >WAN</div>
                <div class="CreditAst-ss-tr-tl"
                style="background: #FFFFFF;box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.2);color: #1A1A1A;margin-left: 15px;"
                >ETC</div>
              </div>
              <div class="CreditAst-ss-tr-s">
                <div class="CreditAst-ss-tr-so">
                  <div class="CreditAst-ss-tr-sol">Transaction</div>
                  <div class="CreditAst-ss-tr-sol">Time</div>
                  <div class="CreditAst-ss-tr-sol">From</div>
                  <div class="CreditAst-ss-tr-sol">To</div>
                  <div class="CreditAst-ss-tr-sol">Block Height</div>
                  <div class="CreditAst-ss-tr-sol">Total Amount</div>
                  <div class="CreditAst-ss-tr-sol">Confirmations</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import methodsData from "./methodsdata";
export default {
  // 定义上面HTML模板中使用的变量
  mixins: [methodsData],
  name: "CreditAst",
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "./CreditAst.less";
</style>

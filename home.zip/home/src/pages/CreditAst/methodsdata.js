// import ChainerView from '../../components/Chainer/Chainer.vue'
import Transaction from '../../assets/graph/Transaction Data/off.svg';
import Historical from '../../assets/graph/Historical Balance/off.svg';
import History from '../../assets/graph/Transaction History/off.svg';
// import Trading from '../../assets/graph/Trading Path/off.svg';
import BCSs from '../../assets/graph/BCS/off.svg';
export default {
    data() {
        return {
            switList:[
                {
                    src:Transaction,
                    name:'Transaction Data'
                },
                {
                    src:Historical,
                    name:'Historical Balance'
                },
                {
                    src:History,
                    name:'Transaction History'
                },
                // {
                //     src:Trading,
                //     name:'Trading Path'
                // },
                {
                    src:BCSs,
                    name:'BCS'
                },
            ]
        }
    },
    components: {
    },
    methods: {
        
    }
}
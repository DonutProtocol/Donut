import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

export default new VueRouter({
    routes: [{
        path: '/',
        redirect: '/Chain'
    },
    {
        path: '/Chain',
        component: () => import('../pages/Chain/Chain.vue'),
    },
    {
        path: '/CreditAst',
        component: () => import('../pages/CreditAst/CreditAst.vue'),
    }
]
})